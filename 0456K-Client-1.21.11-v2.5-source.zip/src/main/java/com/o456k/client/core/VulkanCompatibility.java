package com.o456k.client.core;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import java.util.*;

/** Conservative Vulkan compatibility guard. It only flags explicitly known OpenGL/OptiFine stacks. */
public final class VulkanCompatibility {
    private static final Map<String, String> KNOWN_CONFLICTS = Map.of(
            "optifine", "OptiFine replaces the standard rendering pipeline and is not a Fabric Vulkan target.",
            "optifabric", "OptiFabric loads OptiFine's rendering pipeline and is not a Fabric Vulkan target."
    );
    private static boolean notified;

    private VulkanCompatibility() {}

    public static List<String> conflicts() {
        List<String> found = new ArrayList<>();
        for (ModContainer mod : FabricLoader.getInstance().getAllMods()) {
            String id = mod.getMetadata().getId().toLowerCase(Locale.ROOT);
            if (KNOWN_CONFLICTS.containsKey(id)) found.add(id + " — " + KNOWN_CONFLICTS.get(id));
        }
        return found;
    }

    public static boolean hasKnownConflicts() { return !conflicts().isEmpty(); }

    public static void notifyIfNeeded(Minecraft client) {
        if (notified || client.player == null) return;
        notified = true;
        for (String conflict : conflicts()) {
            client.player.displayClientMessage(Component.literal("§c⚠ Vulkan Compatibility Warning§7: " + conflict), false);
        }
    }
}

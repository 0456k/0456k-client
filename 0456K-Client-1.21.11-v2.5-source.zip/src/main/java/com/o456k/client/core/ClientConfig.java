package com.o456k.client.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

public final class ClientConfig {
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("0456k-client.json");
    public int accent = 0xFF55D6FF;
    public boolean hud = true, fps = true, cps = true, coordinates = true, keystrokes = true, sprint = true;
    public boolean armor = true, crosshair = true, hitColor = true, toggleSneak = false;
    public boolean zoom = false, fullbright = false;
    public final Map<String, Integer> keybinds = new LinkedHashMap<>();
    public final Map<String, Boolean> moduleEnabled = new LinkedHashMap<>();
    public final Map<String, Map<String, String>> settings = new LinkedHashMap<>();

    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public void load() {
        try {
            if (!Files.exists(file)) return;
            JsonObject o = gson.fromJson(Files.readString(file), JsonObject.class);
            if (o == null) return;
            accent = intValue(o, "accent", accent);
            hud = bool(o,"hud",hud); fps = bool(o,"fps",fps); cps = bool(o,"cps",cps);
            coordinates = bool(o,"coordinates",coordinates); keystrokes = bool(o,"keystrokes",keystrokes);
            sprint = bool(o,"sprint",sprint); armor = bool(o,"armor",armor); crosshair = bool(o,"crosshair",crosshair);
            hitColor = bool(o,"hitColor",hitColor); toggleSneak = bool(o,"toggleSneak",toggleSneak);
            zoom = bool(o,"zoom",zoom); fullbright = bool(o,"fullbright",fullbright);
            if (o.has("keybinds") && o.get("keybinds").isJsonObject()) {
                for (var e : o.getAsJsonObject("keybinds").entrySet()) {
                    try { keybinds.put(e.getKey(), e.getValue().getAsInt()); } catch (Exception ignored) {}
                }
            }
            if (o.has("moduleEnabled") && o.get("moduleEnabled").isJsonObject()) {
                for (var e : o.getAsJsonObject("moduleEnabled").entrySet()) {
                    try { moduleEnabled.put(e.getKey(), e.getValue().getAsBoolean()); } catch (Exception ignored) {}
                }
            }
            if (o.has("settings") && o.get("settings").isJsonObject()) {
                for (var module : o.getAsJsonObject("settings").entrySet()) {
                    if (!module.getValue().isJsonObject()) continue;
                    Map<String, String> values = new LinkedHashMap<>();
                    for (var entry : module.getValue().getAsJsonObject().entrySet()) values.put(entry.getKey(), entry.getValue().getAsString());
                    settings.put(module.getKey(), values);
                }
            }
        } catch (Exception ignored) {}
    }

    private static boolean bool(JsonObject o, String k, boolean d) { return o.has(k) ? o.get(k).getAsBoolean() : d; }
    private static int intValue(JsonObject o, String k, int d) { return o.has(k) ? o.get(k).getAsInt() : d; }

    public boolean settingBoolean(String module, String name, boolean fallback) {
        try { return Boolean.parseBoolean(settings.getOrDefault(module, Map.of()).getOrDefault(name, Boolean.toString(fallback))); } catch (Exception ignored) { return fallback; }
    }

    public double settingDouble(String module, String name, double fallback) {
        try { return Double.parseDouble(settings.getOrDefault(module, Map.of()).getOrDefault(name, Double.toString(fallback))); } catch (Exception ignored) { return fallback; }
    }

    public void rememberSetting(String module, String name, Object value) {
        settings.computeIfAbsent(module, k -> new LinkedHashMap<>()).put(name, String.valueOf(value));
    }

    public void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("accent", accent); o.addProperty("hud",hud); o.addProperty("fps",fps); o.addProperty("cps",cps);
            o.addProperty("coordinates",coordinates); o.addProperty("keystrokes",keystrokes); o.addProperty("sprint",sprint);
            o.addProperty("armor",armor); o.addProperty("crosshair",crosshair); o.addProperty("hitColor",hitColor);
            o.addProperty("toggleSneak",toggleSneak); o.addProperty("zoom",zoom); o.addProperty("fullbright",fullbright);
            var binds = new JsonObject();
            keybinds.forEach(binds::addProperty);
            o.add("keybinds", binds);
            var enabled = new JsonObject();
            moduleEnabled.forEach(enabled::addProperty);
            o.add("moduleEnabled", enabled);
            var settingRoot = new JsonObject();
            settings.forEach((module, values) -> {
                var node = new JsonObject();
                values.forEach(node::addProperty);
                settingRoot.add(module, node);
            });
            o.add("settings", settingRoot);
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(tmp, gson.toJson(o), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) {}
    }
}

package com.o456k.client.core.setting;

public final class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String name, boolean defaultValue) { super(name, defaultValue); }
    public void toggle() { set(!get()); }
}

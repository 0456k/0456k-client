package com.o456k.client.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

/** Persistent named client profiles. */
public final class ProfileManager {
    private final ModuleManager modules;
    private final Path root = FabricLoader.getInstance().getConfigDir().resolve("0456k-profiles");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private String active = "Default";

    public ProfileManager(ModuleManager modules) { this.modules = modules; }
    public String active() { return active; }
    public Path directory() { return root; }

    public void save(String name) {
        if (name == null || name.isBlank()) return;
        try {
            Files.createDirectories(root);
            JsonObject out = new JsonObject();
            JsonObject enabled = new JsonObject();
            JsonObject keys = new JsonObject();
            JsonObject settings = new JsonObject();
            for (Module m : modules.all()) {
                enabled.addProperty(m.name(), m.enabled());
                keys.addProperty(m.name(), m.keyCode());
                JsonObject moduleSettings = new JsonObject();
                for (var s : m.settings()) moduleSettings.addProperty(s.name(), String.valueOf(s.get()));
                settings.add(m.name(), moduleSettings);
            }
            out.add("enabled", enabled); out.add("keys", keys); out.add("settings", settings);
            Files.writeString(root.resolve(safe(name) + ".json"), gson.toJson(out));
            active = name;
        } catch (Exception ignored) {}
    }

    public void load(String name) {
        if (name == null || name.isBlank()) return;
        Path file = root.resolve(safe(name) + ".json");
        if (!Files.exists(file)) return;
        try {
            JsonObject in = gson.fromJson(Files.readString(file), JsonObject.class);
            JsonObject enabled = in.has("enabled") ? in.getAsJsonObject("enabled") : new JsonObject();
            JsonObject keys = in.has("keys") ? in.getAsJsonObject("keys") : new JsonObject();
            JsonObject settings = in.has("settings") ? in.getAsJsonObject("settings") : new JsonObject();
            for (Module m : modules.all()) {
                if (enabled.has(m.name())) m.setEnabled(enabled.get(m.name()).getAsBoolean());
                if (keys.has(m.name())) m.setKeyCode(keys.get(m.name()).getAsInt());
                if (settings.has(m.name()) && settings.get(m.name()).isJsonObject()) {
                    for (var s : m.settings()) {
                        var v = settings.getAsJsonObject(m.name()).get(s.name());
                        if (v == null) continue;
                        try {
                            if (s instanceof com.o456k.client.core.setting.BooleanSetting b) b.set(v.getAsBoolean());
                            else if (s instanceof com.o456k.client.core.setting.NumberSetting n) n.set(v.getAsDouble());
                        } catch (Exception ignored) {}
                    }
                }
            }
            active = name;
        } catch (Exception ignored) {}
    }

    public List<String> list() {
        try {
            Files.createDirectories(root);
            try (var stream = Files.list(root)) {
                return stream.filter(p -> p.getFileName().toString().endsWith(".json"))
                        .map(p -> p.getFileName().toString().replaceFirst("\\.json$", ""))
                        .sorted(String.CASE_INSENSITIVE_ORDER).toList();
            }
        } catch (Exception ignored) { return List.of(); }
    }

    private static String safe(String name) { return name.replaceAll("[^a-zA-Z0-9._ -]", "_").trim(); }
}

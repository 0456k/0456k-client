package com.o456k.client.core;

import net.minecraft.client.Minecraft;
import com.o456k.client.core.setting.Setting;
import java.util.*;

public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private int keyCode;
    private final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public final void toggle() { setEnabled(!enabled); }

    public final void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (enabled) onEnable(); else onDisable();
    }

    public boolean enabled() { return enabled; }
    public String name() { return name; }
    public String description() { return description; }
    public Category category() { return category; }
    public int keyCode() { return keyCode; }
    public void setKeyCode(int keyCode) { this.keyCode = keyCode; }
    public <S extends Setting<?>> S addSetting(S setting) { settings.add(setting); return setting; }
    public List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }
    public Setting<?> setting(String name) { return settings.stream().filter(s -> s.name().equalsIgnoreCase(name)).findFirst().orElse(null); }

    public void onEnable() {}
    public void onDisable() {}
    public void tick(Minecraft client) {}

    public enum Category { COMBAT, MOVEMENT, RENDER, HUD, MISC }
}

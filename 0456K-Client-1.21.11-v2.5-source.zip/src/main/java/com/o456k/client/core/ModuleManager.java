package com.o456k.client.core;

import com.o456k.client.feature.*;
import com.o456k.client.ui.HudRenderer;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public final class ModuleManager {
    private final ClientConfig config;
    private final List<Module> modules = new ArrayList<>();
    private final Map<Module, Boolean> keyState = new HashMap<>();

    public ModuleManager(ClientConfig config) { this.config = config; }

    public void registerDefaults() {
        modules.add(new SprintModule(config));
        modules.add(new ZoomModule(config));
        modules.add(new FullbrightModule());
        modules.add(new FPSModule(config));
        modules.add(new CPSModule(config));
        modules.add(new CoordinatesModule(config));
        modules.add(new KeystrokesModule(config));
        modules.add(new ArmorHUDModule(config));
        modules.add(new CrosshairModule());
        modules.add(new ToggleSneakModule());
        modules.add(new HitColorModule());
        modules.add(new PerformanceModule());
        modules.add(new TargetHUDModule());
        modules.add(new ServerInfoModule());
        modules.add(new DiscordInviteModule());
        modules.add(new FriendsHUDModule());
        modules.add(new ModListModule());
        modules.add(new ResourcePackListModule());
        HudRenderer.install(config, this);
        bind("Sprint", GLFW.GLFW_KEY_G);
        bind("Zoom", GLFW.GLFW_KEY_C);
        bind("Fullbright", GLFW.GLFW_KEY_B);
        bind("ToggleSneak", GLFW.GLFW_KEY_N);
        for (Module m : modules) {
            keyState.put(m, false);
            Boolean savedEnabled = config.moduleEnabled.get(m.name());
            if (savedEnabled != null && savedEnabled != m.enabled()) m.setEnabled(savedEnabled);
            restoreSettings(m);
        }
    }

    public void tick(Minecraft client) {
        long window = client.getWindow().handle();
        for (Module m : modules) {
            int key = m.keyCode();
            if (key > 0) {
                boolean down = InputConstants.isKeyDown(window, key);
                boolean wasDown = keyState.getOrDefault(m, false);
                if (down && !wasDown) {
                    m.toggle();
                    syncConfig(m);
                    config.moduleEnabled.put(m.name(), m.enabled());
                    config.save();
                }
                keyState.put(m, down);
            }
            if (m.enabled()) m.tick(client);
        }
    }

    public void bind(String name, int key) {
        Module m = get(name);
        if (m == null) return;
        Integer saved = config.keybinds.get(name);
        m.setKeyCode(saved != null ? saved : key);
        config.keybinds.putIfAbsent(name, m.keyCode());
    }

    public void setKey(Module m, int key) {
        if (key > 0) {
            Module existing = modules.stream().filter(other -> other != m && other.keyCode() == key).findFirst().orElse(null);
            if (existing != null) {
                existing.setKeyCode(0);
                config.keybinds.put(existing.name(), 0);
            }
        }
        m.setKeyCode(key);
        config.keybinds.put(m.name(), key);
        keyState.put(m, false);
        config.save();
    }

    public void syncConfig(Module m) {
        config.moduleEnabled.put(m.name(), m.enabled());
        switch (m.name()) {
            case "Sprint" -> config.sprint=m.enabled();
            case "Zoom" -> config.zoom=m.enabled();
            case "Fullbright" -> config.fullbright=m.enabled();
            case "FPS" -> config.fps=m.enabled();
            case "CPS" -> config.cps=m.enabled();
            case "Coordinates" -> config.coordinates=m.enabled();
            case "Keystrokes" -> config.keystrokes=m.enabled();
            case "Armor" -> config.armor=m.enabled();
            case "Crosshair" -> config.crosshair=m.enabled();
            case "HitColor" -> config.hitColor=m.enabled();
            case "ToggleSneak" -> config.toggleSneak=m.enabled();
            case "Performance", "TargetHUD", "ServerInfo", "Discord", "FriendsHUD", "ModList", "TexturePacks" -> { /* state is stored by module name. */ }
        }
    }

    private void restoreSettings(Module m) {
        for (var setting : m.settings()) {
            if (setting instanceof com.o456k.client.core.setting.BooleanSetting b) {
                b.set(config.settingBoolean(m.name(), setting.name(), b.get()));
            } else if (setting instanceof com.o456k.client.core.setting.NumberSetting n) {
                n.set(config.settingDouble(m.name(), setting.name(), n.get()));
            }
        }
    }

    public void persistSettings(Module m) {
        config.moduleEnabled.put(m.name(), m.enabled());
        for (var setting : m.settings()) config.rememberSetting(m.name(), setting.name(), setting.get());
        config.save();
    }

    public List<Module> all() { return Collections.unmodifiableList(modules); }
    public List<Module> category(Module.Category category) {
        return modules.stream().filter(m -> m.category() == category).toList();
    }
    public Module get(String name) {
        return modules.stream().filter(m -> m.name().equalsIgnoreCase(name)).findFirst().orElse(null);
    }
}

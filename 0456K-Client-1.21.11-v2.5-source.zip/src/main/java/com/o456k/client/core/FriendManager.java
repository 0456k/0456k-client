package com.o456k.client.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

/** Lightweight local friends list. It never sends data to a server. */
public final class FriendManager {
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("0456k-friends.json");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Set<String> friends = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

    public void load() {
        try {
            if (!Files.exists(file)) return;
            String[] values = gson.fromJson(Files.readString(file), String[].class);
            if (values != null) friends.addAll(Arrays.asList(values));
        } catch (Exception ignored) {}
    }
    public void add(String name) { if (name != null && !name.isBlank()) { friends.add(name.trim()); save(); } }
    public void remove(String name) { if (name != null) { friends.remove(name.trim()); save(); } }
    public boolean contains(String name) { return name != null && friends.contains(name); }
    public List<String> all() { return List.copyOf(friends); }
    private void save() {
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, gson.toJson(friends));
        } catch (Exception ignored) {}
    }
}

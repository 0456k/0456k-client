package com.o456k.client.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashMap;
import java.util.Map;

/** Persistent normalized HUD layout. Coordinates are stored in GUI pixels for the current scaled size. */
public final class HudLayout {
    public static final String CLIENT = "client";
    public static final String FPS = "fps";
    public static final String COORDINATES = "coordinates";
    public static final String CPS = "cps";
    public static final String KEYSTROKES = "keystrokes";
    public static final String CROSSHAIR = "crosshair";
    public static final String ARMOR = "armor";

    public static final class Pos {
        public int x, y;
        public Pos(int x, int y) { this.x = x; this.y = y; }
    }

    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("0456k-hud.json");
    private final Map<String, Pos> positions = new LinkedHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public HudLayout() {
        defaults();
    }

    public void defaults() {
        positions.clear();
        positions.put(CLIENT, new Pos(8, 8));
        positions.put(FPS, new Pos(8, 38));
        positions.put(COORDINATES, new Pos(8, 50));
        positions.put(CPS, new Pos(8, 62));
        positions.put(KEYSTROKES, new Pos(8, 80));
        positions.put(CROSSHAIR, new Pos(-1, -1)); // centered sentinel
        positions.put(ARMOR, new Pos(-1, -1));
    }

    public Pos get(String id) { return positions.computeIfAbsent(id, k -> new Pos(8, 8)); }

    public void set(String id, int x, int y) {
        get(id).x = x;
        get(id).y = y;
    }

    public void load() {
        try {
            if (!Files.exists(file)) return;
            JsonObject root = gson.fromJson(Files.readString(file), JsonObject.class);
            if (root == null) return;
            for (String id : positions.keySet()) {
                if (!root.has(id) || !root.get(id).isJsonObject()) continue;
                JsonObject p = root.getAsJsonObject(id);
                get(id).x = p.has("x") ? p.get("x").getAsInt() : get(id).x;
                get(id).y = p.has("y") ? p.get("y").getAsInt() : get(id).y;
            }
        } catch (Exception ignored) { }
    }

    public void save() {
        try {
            JsonObject root = new JsonObject();
            for (var e : positions.entrySet()) {
                JsonObject p = new JsonObject();
                p.addProperty("x", e.getValue().x);
                p.addProperty("y", e.getValue().y);
                root.add(e.getKey(), p);
            }
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(tmp, gson.toJson(root), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(tmp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ex) { Files.move(tmp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }
}

package com.o456k.client;

import com.o456k.client.core.ClientConfig;
import com.o456k.client.core.ModuleManager;
import com.o456k.client.core.HudLayout;
import com.o456k.client.core.ProfileManager;
import com.o456k.client.core.FriendManager;
import com.o456k.client.core.VulkanCompatibility;
import com.o456k.client.ui.HudEditorScreen;
import com.o456k.client.ui.ClickGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

public final class ClientMain implements ClientModInitializer {
    public static final String MOD_ID = "0456kclient";
    public static final ClientConfig CONFIG = new ClientConfig();
    public static ModuleManager MODULES;
    public static ProfileManager PROFILES;
    public static FriendManager FRIENDS;
    public static final HudLayout HUD = new HudLayout();
    private static KeyMapping clickGuiKey;
    private static KeyMapping zoomKey;
    private static KeyMapping homeKey;
    private static KeyMapping friendsKey;

    @Override
    public void onInitializeClient() {
        CONFIG.load();
        HUD.load();
        MODULES = new ModuleManager(CONFIG);
        MODULES.registerDefaults();
        PROFILES = new ProfileManager(MODULES);
        FRIENDS = new FriendManager();
        FRIENDS.load();
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.0456kclient.open_gui", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC));
        KeyMapping hudEditorKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.0456kclient.hud_editor", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F8,
                KeyMapping.Category.MISC));
        homeKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.0456kclient.home", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F7, KeyMapping.Category.MISC));
        friendsKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.0456kclient.friends", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F6, KeyMapping.Category.MISC));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.0456kclient.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            MODULES.tick(client);
            VulkanCompatibility.notifyIfNeeded(client);
            while (clickGuiKey.consumeClick()) client.setScreen(new ClickGuiScreen(client.screen));
            while (hudEditorKey.consumeClick()) client.setScreen(new HudEditorScreen(client.screen));
            while (homeKey.consumeClick()) client.setScreen(new com.o456k.client.ui.ClientHomeScreen(client.screen));
            while (friendsKey.consumeClick()) client.setScreen(new com.o456k.client.ui.FriendsScreen(client.screen));
        });
    }

    public static boolean isZoomHeld() { return zoomKey != null && zoomKey.isDown(); }
    public static Identifier id(String path) { return Identifier.fromNamespaceAndPath(MOD_ID, path); }
    public static Minecraft mc() { return Minecraft.getInstance(); }
}

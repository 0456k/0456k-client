package com.o456k.client.ui;

import com.o456k.client.ClientMain;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

/** Local friends manager UI. */
public final class FriendsScreen extends Screen {
    private final Screen parent;
    private EditBox input;
    private String status = "";

    public FriendsScreen(Screen parent) {
        super(Component.literal("0456K Friends"));
        this.parent = parent;
    }

    @Override protected void init() {
        input = new EditBox(font, width / 2 - 140, height / 2 - 82, 280, 20, Component.literal("Player name"));
        input.setMaxLength(32);
        addRenderableWidget(input);
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xF0080A10);
        int w = 560, h = 360, left = Math.max(20, (width - w) / 2), top = Math.max(20, (height - h) / 2);
        g.fill(left, top, left + w, top + h, 0xFF11151F);
        g.fill(left, top, left + 5, top + h, ClientMain.CONFIG.accent);
        g.drawString(font, "FRIENDS", left + 22, top + 20, ClientMain.CONFIG.accent);
        g.drawString(font, "Local friend list • saved automatically", left + 22, top + 38, 0xFF7E8497);
        g.drawString(font, "ADD PLAYER", left + 22, top + 66, 0xFFB8BECC);
        g.fill(left + 22, top + 92, left + 172, top + 122, 0xFF1A202C);
        g.drawCenteredString(font, "ADD", left + 97, top + 102, ClientMain.CONFIG.accent);
        g.fill(left + 22, top + 145, left + w - 22, top + h - 42, 0xFF181D28);
        int y = top + 157;
        for (String friend : ClientMain.FRIENDS.all()) {
            if (y > top + h - 66) break;
            g.drawString(font, friend, left + 36, y, 0xFFFFFFFF);
            g.drawString(font, "FRIEND", left + w - 105, y, 0xFF6F778A);
            y += 24;
        }
        if (ClientMain.FRIENDS.all().isEmpty()) g.drawString(font, "No friends yet.", left + 36, top + 162, 0xFF6F778A);
        if (!status.isBlank()) g.drawString(font, status, left + 22, top + h - 27, 0xFF7ED6A8);
        super.render(g, mouseX, mouseY, delta);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        int w = 560, h = 360, left = Math.max(20, (width - w) / 2), top = Math.max(20, (height - h) / 2);
        if (button == 0 && mx >= left + 22 && mx < left + 172 && my >= top + 92 && my < top + 122) {
            String name = input.getValue().trim();
            if (!name.isBlank()) { ClientMain.FRIENDS.add(name); input.setValue(""); status = name + " added."; }
            return true;
        }
        if (button == 1 && mx >= left + 22 && mx < left + w - 22 && my >= top + 145 && my < top + h - 42) {
            int index = (int)((my - (top + 157)) / 24);
            var friends = ClientMain.FRIENDS.all();
            if (index >= 0 && index < friends.size()) { String name = friends.get(index); ClientMain.FRIENDS.remove(name); status = name + " removed."; return true; }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}

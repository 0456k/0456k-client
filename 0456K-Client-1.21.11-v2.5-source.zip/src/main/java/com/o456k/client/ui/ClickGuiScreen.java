package com.o456k.client.ui;

import com.o456k.client.ClientMain;
import com.o456k.client.core.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.*;

public final class ClickGuiScreen extends Screen {
    private final Screen parent;
    private Module.Category category = Module.Category.MOVEMENT;
    private int scroll;
    private Module rebinding;
    private float openAnim;
    private String search = "";

    public ClickGuiScreen(Screen parent){ super(Component.literal("0456K Client")); this.parent=parent; }

    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta){
        openAnim += (1f - openAnim) * Math.min(1f, delta * 0.18f);
        g.fill(0,0,width,height,0xD9080A10);
        int left=Math.max(20,width/2-310), top=Math.max(20,height/2-190), right=left+620,bottom=top+380;
        int panelTop = top + Math.round((1f-openAnim)*18f);
        g.fill(left,panelTop,right,bottom,0xFF11131C);
        top = panelTop;
        g.fill(left,top,left+5,bottom,ClientMain.CONFIG.accent);
        g.drawString(font,"0456K CLIENT",left+20,top+16,ClientMain.CONFIG.accent);
        g.drawString(font,"PvP Client • 1.21.11",left+20,top+32,0xFF777D90);

        int tabX=left+18;
        for(Module.Category c:Module.Category.values()){
            int w=94; boolean selected=c==category;
            g.fill(tabX,top+52,tabX+w,top+78,selected?0xFF243446:0xFF181A23);
            g.drawCenteredString(font,c.name(),tabX+w/2,top+61,selected?ClientMain.CONFIG.accent:0xFF9AA0B2);
            tabX+=100;
        }

        List<Module> list=filteredModules();
        int y=top+92+scroll;
        for(Module m:list){
            int x=left+18;
            if(y>=top+84 && y<bottom-34){
                int bg=m.enabled()?0xFF1D2B38:0xFF181A23;
                g.fill(x,y,right-18,y+40,bg);
                g.fill(x,y,x+3,y+40,m.enabled()?ClientMain.CONFIG.accent:0xFF30333F);
                g.drawString(font,m.name(),x+12,y+8,m.enabled()?ClientMain.CONFIG.accent:0xFFFFFFFF);
                g.drawString(font,m.description(),x+12,y+23,0xFF7E8497);
                String key = rebinding == m ? "PRESS KEY" : keyName(m.keyCode());
                g.drawString(font,key,right-112,y+14,rebinding == m ? ClientMain.CONFIG.accent : 0xFF777D90);
                g.drawString(font,m.settings().isEmpty()?"":"SET",right-74,y+14,0xFF9AA0B2);
                g.drawString(font,m.enabled()?"ON":"OFF",right-42,y+14,m.enabled()?ClientMain.CONFIG.accent:0xFF777D90);
            }
            y+=46;
        }
        g.fill(right-185,top+15,right-20,top+39,0xFF181A23);
        g.drawString(font, search.isBlank() ? "Search modules..." : search, right-177, top+23, search.isBlank()?0xFF666B7A:0xFFFFFFFF);
        g.drawCenteredString(font,"Click toggle • Right-click rebind • Type to search • Wheel scroll",width/2,bottom-20,0xFF777D90);
        super.render(g,mouseX,mouseY,delta);
    }

    @Override public boolean mouseClicked(double mx,double my,int button){
        int left=Math.max(20,width/2-310), top=Math.max(20,height/2-190), right=left+620,bottom=top+380;
        if(my>=top+52&&my<top+78){
            int tab=(int)((mx-(left+18))/100);
            if(tab>=0&&tab<Module.Category.values().length){category=Module.Category.values()[tab];scroll=0;return true;}
        }
        if(mx>=right-185&&mx<right-20&&my>=top+15&&my<top+39){ return true; }
        if(mx>=left+18&&mx<right-18&&my>=top+84&&my<bottom-34){
            int index=(int)((my-(top+92+scroll))/46);
            var list=filteredModules();
            if(index>=0&&index<list.size()) {
                Module m = list.get(index);
                if (button == 1) { rebinding = m; return true; }
                if (mx >= right - 88 && !m.settings().isEmpty()) { minecraft.setScreen(new ModuleSettingsScreen(this, m)); return true; }
                m.toggle(); ClientMain.MODULES.syncConfig(m); ClientMain.CONFIG.save(); return true;
            }
        }
        return super.mouseClicked(mx,my,button);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (rebinding != null) {
            if (keyCode == 256) { rebinding = null; return true; }
            ClientMain.MODULES.setKey(rebinding, keyCode);
            rebinding = null;
            return true;
        }
        if (keyCode == 259) { // backspace
            if (!search.isEmpty()) search = search.substring(0, search.length()-1);
            scroll = 0;
            return true;
        }
        if (keyCode == 256) return super.keyPressed(keyCode, scanCode, modifiers);
        String name = org.lwjgl.glfw.GLFW.glfwGetKeyName(keyCode, 0);
        if (name != null && !name.isBlank() && modifiers == 0) {
            search += name;
            scroll = 0;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private List<Module> filteredModules() {
        String query = search.trim().toLowerCase(Locale.ROOT);
        return ClientMain.MODULES.category(category).stream()
                .filter(m -> query.isEmpty() || m.name().toLowerCase(Locale.ROOT).contains(query)
                        || m.description().toLowerCase(Locale.ROOT).contains(query))
                .toList();
    }

    private static String keyName(int key) {
        if (key <= 0) return "NONE";
        String name = org.lwjgl.glfw.GLFW.glfwGetKeyName(key, 0);
        if (name != null) return name.toUpperCase(Locale.ROOT);
        return switch (key) {
            case 256 -> "ESC"; case 257 -> "ENTER"; case 258 -> "TAB"; case 32 -> "SPACE";
            default -> "KEY " + key;
        };
    }

    @Override public boolean mouseScrolled(double mx,double my,double horizontal,double vertical){
        scroll += vertical>0 ? 46 : -46;
        scroll=Math.min(0,Math.max(-Math.max(0,filteredModules().size()-5)*46,scroll));
        return true;
    }
    @Override public void onClose(){minecraft.setScreen(parent);}
    @Override public boolean shouldCloseOnEsc(){return true;}
}

package com.o456k.client.ui;

import com.o456k.client.ClientMain;
import com.o456k.client.core.*;
import com.o456k.client.feature.CPSModule;
import com.o456k.client.feature.CrosshairModule;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;

public final class HudRenderer {
    private HudRenderer() {}

    public static void install(ClientConfig c, ModuleManager modules) {
        HudElementRegistry.addLast(ClientMain.id("hud"), (g, delta) -> render(g, c, modules));
    }

    private static void render(GuiGraphics g, ClientConfig c, ModuleManager modules) {
        Minecraft m = Minecraft.getInstance();
        if (m.player == null || !c.hud) return;
        int sw = m.getWindow().getGuiScaledWidth();
        int sh = m.getWindow().getGuiScaledHeight();
        int x = ClientMain.HUD.get(com.o456k.client.core.HudLayout.CLIENT).x;
        int y = ClientMain.HUD.get(com.o456k.client.core.HudLayout.CLIENT).y;
        if (x < 0) x = 8; if (y < 0) y = 8;

        g.fill(x - 4, y - 4, x + 122, y + 16, 0xB0101018);
        g.fill(x - 4, y - 4, x, y + 16, c.accent);
        g.drawString(m.font, Component.literal("0456K CLIENT"), x + 4, y, c.accent);

        int line = y + 30;
        if (modules.get("FPS") != null && modules.get("FPS").enabled()) {
            var p = ClientMain.HUD.get(com.o456k.client.core.HudLayout.FPS);
            g.drawString(m.font, Component.literal("FPS: " + m.getFps()), p.x >= 0 ? p.x : x, p.y >= 0 ? p.y : line, 0xFFFFFFFF); line += 12;
        }
        if (modules.get("Coordinates") != null && modules.get("Coordinates").enabled()) {
            LocalPlayer p = m.player;
            var hp = ClientMain.HUD.get(com.o456k.client.core.HudLayout.COORDINATES);
            g.drawString(m.font, Component.literal(String.format("XYZ: %d %d %d", p.getBlockX(), p.getBlockY(), p.getBlockZ())), hp.x >= 0 ? hp.x : x, hp.y >= 0 ? hp.y : line, 0xFFE8E8E8); line += 12;
        }
        if (modules.get("ServerInfo") != null && modules.get("ServerInfo").enabled()) {
            var sm = (com.o456k.client.feature.ServerInfoModule) modules.get("ServerInfo");
            g.drawString(m.font, Component.literal("Server: " + sm.address(m) + "  Ping: " + (sm.ping(m) < 0 ? "--" : sm.ping(m) + "ms")), x, line, 0xFFFFFFFF); line += 12;
        }
        if (modules.get("Discord") != null && modules.get("Discord").enabled()) {
            g.drawString(m.font, Component.literal("Discord: " + com.o456k.client.feature.DiscordInviteModule.INVITE), x, line, c.accent); line += 12;
        }
        if (modules.get("FriendsHUD") != null && modules.get("FriendsHUD").enabled()) {
            g.drawString(m.font, Component.literal("Friends: " + ClientMain.FRIENDS.all().size()), x, line, 0xFFFFFFFF); line += 12;
        }

        if (modules.get("CPS") != null && modules.get("CPS").enabled()) {
            CPSModule cps = (CPSModule) modules.get("CPS");
            var cp = ClientMain.HUD.get(com.o456k.client.core.HudLayout.CPS);
            g.drawString(m.font, Component.literal("CPS: " + cps.leftCps() + " | " + cps.rightCps()), cp.x >= 0 ? cp.x : x, cp.y >= 0 ? cp.y : line, 0xFFFFFFFF); line += 12;
        }

        if (modules.get("Keystrokes") != null && modules.get("Keystrokes").enabled()) drawKeystrokes(g, m, ClientMain.HUD.get(com.o456k.client.core.HudLayout.KEYSTROKES).x, ClientMain.HUD.get(com.o456k.client.core.HudLayout.KEYSTROKES).y);
        if (modules.get("Crosshair") != null && modules.get("Crosshair").enabled()) {
            var cp = ClientMain.HUD.get(com.o456k.client.core.HudLayout.CROSSHAIR);
            { CrosshairModule cm = (CrosshairModule) modules.get("Crosshair"); drawCrosshair(g, m, cp.x < 0 ? sw / 2 : cp.x, cp.y < 0 ? sh / 2 : cp.y, c.accent, cm); }
        }
        if (modules.get("Armor") != null && modules.get("Armor").enabled()) {
            var ap = ClientMain.HUD.get(com.o456k.client.core.HudLayout.ARMOR);
            drawArmor(g, m, ap.x < 0 ? sw / 2 - 74 : ap.x, ap.y < 0 ? sh - 42 : ap.y);
        }

        if (modules.get("TargetHUD") != null && modules.get("TargetHUD").enabled()) {
            drawTargetHud(g, m, (com.o456k.client.feature.TargetHUDModule) modules.get("TargetHUD"));
        }
    }

    private static void drawKeystrokes(GuiGraphics g, Minecraft m, int x, int y) {
        key(g,m,"W",x+22,y,m.options.keyUp.isDown());
        key(g,m,"A",x,y+20,m.options.keyLeft.isDown());
        key(g,m,"S",x+22,y+20,m.options.keyDown.isDown());
        key(g,m,"D",x+44,y+20,m.options.keyRight.isDown());
        key(g,m,"LMB",x,y+40,m.mouseHandler.isLeftPressed());
        key(g,m,"RMB",x+44,y+40,m.mouseHandler.isRightPressed());
    }

    private static void key(GuiGraphics g, Minecraft m, String text, int x, int y, boolean down) {
        int bg = down ? 0xDD27394A : 0xAA101018;
        g.fill(x,y,x+20,y+18,bg);
        g.drawCenteredString(m.font,text,x+10,y+5,0xFFFFFFFF);
    }

    private static void drawCrosshair(GuiGraphics g, Minecraft m, int cx, int cy, int accent, CrosshairModule cm) {
        int size = (int)Math.round(cm.size.get());
        int thick = (int)Math.round(cm.thickness.get());
        int half = Math.max(1, thick / 2);
        g.fill(cx-half, cy-size, cx+half+1, cy+size+1, 0xFFFFFFFF);
        g.fill(cx-size, cy-half, cx+size+1, cy+half+1, 0xFFFFFFFF);
        g.fill(cx-half, cy-half, cx+half+1, cy+half+1, accent);
    }

    private static void drawTargetHud(GuiGraphics g, Minecraft m, com.o456k.client.feature.TargetHUDModule module) {
        if (!(m.hitResult instanceof EntityHitResult hit)) return;
        Entity target = hit.getEntity();
        if (target == null || target == m.player) return;
        float scale = (float) module.scale.get();
        int x = 10, y = m.getWindow().getGuiScaledHeight() - 92;
        int w = (int)(154 * scale), h = (int)(46 * scale);
        g.fill(x, y, x + w, y + h, 0xCC101018);
        g.fill(x, y, x + 3, y + h, ClientMain.CONFIG.accent);
        g.drawString(m.font, target.getName(), x + 9, y + 7, 0xFFFFFFFF);
        double distance = m.player.distanceTo(target);
        if (module.showDistance.get()) g.drawString(m.font, String.format("%.1fm", distance), x + 9, y + 21, 0xFFCCCCCC);
        if (module.showHealth.get() && target instanceof net.minecraft.world.entity.LivingEntity living) {
            float hp = Math.max(0f, living.getHealth());
            float max = Math.max(1f, living.getMaxHealth());
            int barW = Math.max(4, (int)((w - 18) * (hp / max)));
            g.fill(x + 9, y + 35, x + w - 9, y + 39, 0xFF303038);
            g.fill(x + 9, y + 35, x + 9 + barW, y + 39, ClientMain.CONFIG.accent);
        }
    }

    private static void drawArmor(GuiGraphics g, Minecraft m, int x, int y) {
        for (int i=0;i<4;i++) {
            var stack = m.player.getInventory().getArmor(i);
            int px = x + i * 36;
            g.fill(px-2,y-2,px+34,y+34,0xAA101018);
            if (!stack.isEmpty()) {
                g.renderItem(stack, px+8, y+7);
                if (stack.isDamageableItem()) {
                    int max = stack.getMaxDamage();
                    int remaining = max - stack.getDamageValue();
                    g.drawString(m.font, Integer.toString((int)(remaining * 100.0 / max)) + "%", px+2, y+23, 0xFFFFFFFF);
                }
            }
        }
    }
}

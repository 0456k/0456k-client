package com.o456k.client.ui;

import com.o456k.client.ClientMain;
import com.o456k.client.core.Module;
import com.o456k.client.core.setting.BooleanSetting;
import com.o456k.client.core.setting.NumberSetting;
import com.o456k.client.core.setting.Setting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.Locale;

public final class ModuleSettingsScreen extends Screen {
    private final Screen parent;
    private final Module module;

    public ModuleSettingsScreen(Screen parent, Module module) {
        super(Component.literal(module.name() + " Settings"));
        this.parent = parent;
        this.module = module;
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0,0,width,height,0xD9080A10);
        int left = Math.max(30, width / 2 - 220), top = Math.max(30, height / 2 - 150);
        int right = left + 440, bottom = top + 300;
        g.fill(left, top, right, bottom, 0xFF11131C);
        g.fill(left, top, left + 5, bottom, ClientMain.CONFIG.accent);
        g.drawString(font, module.name(), left + 20, top + 18, ClientMain.CONFIG.accent);
        g.drawString(font, module.description(), left + 20, top + 36, 0xFF777D90);

        int y = top + 64;
        for (Setting<?> setting : module.settings()) {
            boolean hover = mouseX >= left + 18 && mouseX <= right - 18 && mouseY >= y && mouseY < y + 42;
            g.fill(left + 18, y, right - 18, y + 38, hover ? 0xFF202531 : 0xFF181A23);
            g.drawString(font, setting.name(), left + 30, y + 7, 0xFFFFFFFF);
            String value = value(setting);
            g.drawString(font, value, right - 110, y + 7, ClientMain.CONFIG.accent);
            if (setting instanceof NumberSetting n) {
                double pct = (n.get() - n.min()) / (n.max() - n.min());
                int barLeft = left + 30, barRight = right - 30;
                g.fill(barLeft, y + 28, barRight, y + 31, 0xFF30333F);
                g.fill(barLeft, y + 28, barLeft + (int)((barRight-barLeft)*pct), y + 31, ClientMain.CONFIG.accent);
            }
            y += 48;
        }
        g.drawCenteredString(font, "Click a setting to change it • ESC to return", width/2, bottom - 24, 0xFF777D90);
        super.render(g, mouseX, mouseY, delta);
    }

    private static String value(Setting<?> s) {
        if (s instanceof NumberSetting n) return String.format(Locale.ROOT, "%.2f", n.get());
        return String.valueOf(s.get()).toUpperCase(Locale.ROOT);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        int left = Math.max(30, width / 2 - 220), top = Math.max(30, height / 2 - 150);
        int y = top + 64;
        for (Setting<?> setting : module.settings()) {
            if (mx >= left + 18 && mx <= left + 422 && my >= y && my < y + 42) {
                if (setting instanceof BooleanSetting b) b.toggle();
                else if (setting instanceof NumberSetting n) {
                    double direction = button == 1 ? -1.0 : 1.0;
                    n.set(n.get() + direction * n.step());
                }
                ClientMain.MODULES.persistSettings(module);
                return true;
            }
            y += 48;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public boolean shouldCloseOnEsc() { return true; }
}

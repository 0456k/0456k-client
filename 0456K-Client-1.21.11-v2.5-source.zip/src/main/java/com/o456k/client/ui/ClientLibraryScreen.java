package com.o456k.client.ui;

import com.o456k.client.ClientMain;
import com.o456k.client.core.VulkanCompatibility;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.*;

/** Mods and resource-pack library with a conservative Vulkan compatibility view. */
public final class ClientLibraryScreen extends Screen {
    private final Screen parent;
    private int tab;
    private int scroll;
    private String search = "";

    public ClientLibraryScreen(Screen parent) {
        super(Component.literal("0456K Library"));
        this.parent = parent;
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xE9080A10);
        int left = Math.max(20, width / 2 - 310), top = Math.max(20, height / 2 - 205);
        int right = left + 620, bottom = top + 410;
        g.fill(left, top, right, bottom, 0xFF11131C);
        g.fill(left, top, left + 5, bottom, ClientMain.CONFIG.accent);
        g.drawString(font, "0456K LIBRARY", left + 20, top + 16, ClientMain.CONFIG.accent);
        g.drawString(font, "Mods • Texture Packs • Vulkan Guard", left + 20, top + 32, 0xFF777D90);

        tab(g, left + 18, top + 52, 130, "MODS", tab == 0);
        tab(g, left + 154, top + 52, 150, "TEXTURE PACKS", tab == 1);
        tab(g, left + 310, top + 52, 150, "VULKAN", tab == 2);
        g.fill(right - 145, top + 52, right - 18, top + 78, 0xFF181A23);
        g.drawString(font, search.isBlank() ? "Search..." : search, right - 137, top + 61,
                search.isBlank() ? 0xFF666B7A : 0xFFFFFFFF);

        if (tab == 0) renderMods(g, left, top, right, bottom);
        else if (tab == 1) renderPacks(g, left, top, right, bottom);
        else renderVulkan(g, left, top, right, bottom);

        g.drawCenteredString(font, "ESC to close • Type to search • Mouse wheel to scroll", width / 2, bottom - 17, 0xFF777D90);
        super.render(g, mouseX, mouseY, delta);
    }

    private void renderMods(GuiGraphics g, int left, int top, int right, int bottom) {
        List<ModContainer> mods = FabricLoader.getInstance().getAllMods().stream()
                .filter(m -> matches(m.getMetadata().getName() + " " + m.getMetadata().getId()))
                .sorted(Comparator.comparing(m -> m.getMetadata().getName().toLowerCase(Locale.ROOT)))
                .toList();
        int y = top + 91 + scroll;
        for (ModContainer mod : mods) {
            if (y >= top + 84 && y < bottom - 32) {
                g.fill(left + 18, y, right - 18, y + 40, 0xFF181A23);
                g.fill(left + 18, y, left + 21, y + 40, ClientMain.CONFIG.accent);
                String name = mod.getMetadata().getName();
                String id = mod.getMetadata().getId();
                g.drawString(font, name, left + 31, y + 7, 0xFFFFFFFF);
                g.drawString(font, id + "  •  " + mod.getMetadata().getVersion().getFriendlyString(), left + 31, y + 22, 0xFF7E8497);
            }
            y += 46;
        }
        if (mods.isEmpty()) g.drawString(font, "No matching mods.", left + 24, top + 100, 0xFF9AA0B2);
    }

    private void renderPacks(GuiGraphics g, int left, int top, int right, int bottom) {
        g.fill(left + 18, top + 91, right - 18, top + 139, 0xFF181A23);
        g.drawString(font, "PRO PLAYERS' TEXTURE PACKS", left + 31, top + 102, ClientMain.CONFIG.accent);
        g.drawString(font, "Pack catalog integration is ready for local pack discovery.", left + 31, top + 119, 0xFF9AA0B2);
        g.drawString(font, "Use Minecraft's Resource Packs screen to activate a pack.", left + 31, top + 134, 0xFF666B7A);
        g.drawString(font, "0456K PvP packs", left + 24, top + 164, 0xFFFFFFFF);
        g.drawString(font, "Client-side resource-pack selections will be attached to profiles next.", left + 24, top + 183, 0xFF7E8497);
    }

    private void renderVulkan(GuiGraphics g, int left, int top, int right, int bottom) {
        boolean conflict = VulkanCompatibility.hasKnownConflicts();
        g.fill(left + 18, top + 91, right - 18, top + 145, conflict ? 0xFF38201F : 0xFF1B3028);
        g.drawString(font, conflict ? "KNOWN CONFLICTS DETECTED" : "NO KNOWN CONFLICTS DETECTED", left + 31, top + 103,
                conflict ? 0xFFFF8B82 : 0xFF72D6B0);
        g.drawString(font, conflict ? "Review the mods below before using a Vulkan renderer." : "The guard found no explicitly blocked rendering stack.", left + 31, top + 121, 0xFFB7BBC7);
        int y = top + 164;
        for (String line : VulkanCompatibility.conflicts()) {
            g.drawString(font, "• " + line, left + 24, y, 0xFFFF9A92);
            y += 28;
        }
        if (!conflict) g.drawString(font, "Compatibility is conservative: unknown mods are marked for review rather than falsely blocked.", left + 24, y, 0xFF7E8497);
    }

    private boolean matches(String text) {
        String q = search.trim().toLowerCase(Locale.ROOT);
        return q.isEmpty() || text.toLowerCase(Locale.ROOT).contains(q);
    }

    private void tab(GuiGraphics g, int x, int y, int w, String text, boolean selected) {
        g.fill(x, y, x + w, y + 26, selected ? 0xFF243446 : 0xFF181A23);
        g.drawCenteredString(font, text, x + w / 2, y + 8, selected ? ClientMain.CONFIG.accent : 0xFF9AA0B2);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        int left = Math.max(20, width / 2 - 310), top = Math.max(20, height / 2 - 205), right = left + 620;
        if (my >= top + 52 && my < top + 78) {
            if (mx >= left + 18 && mx < left + 148) tab = 0;
            else if (mx >= left + 154 && mx < left + 304) tab = 1;
            else if (mx >= left + 310 && mx < left + 460) tab = 2;
            scroll = 0;
            return true;
        }
        if (mx >= right - 145 && mx < right - 18 && my >= top + 52 && my < top + 78) return true;
        return super.mouseClicked(mx, my, button);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 259) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); scroll = 0; return true; }
        if (keyCode == 256) return super.keyPressed(keyCode, scanCode, modifiers);
        String name = org.lwjgl.glfw.GLFW.glfwGetKeyName(keyCode, 0);
        if (name != null && !name.isBlank() && modifiers == 0) { search += name; scroll = 0; return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scroll += vertical > 0 ? 46 : -46;
        int count = tab == 0 ? FabricLoader.getInstance().getAllMods().size() : 4;
        scroll = Math.min(0, Math.max(-Math.max(0, count - 6) * 46, scroll));
        return true;
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}

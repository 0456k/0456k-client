package com.o456k.client.ui;

import com.o456k.client.ClientMain;
import com.o456k.client.core.HudLayout;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Simple, dependency-free HUD editor: drag a widget, release to persist. */
public final class HudEditorScreen extends Screen {
    private final Screen parent;
    private String selected;
    private int grabX, grabY, originX, originY;

    private record Box(String id, String label, int x, int y, int w, int h) {}

    public HudEditorScreen(Screen parent) {
        super(Component.literal("0456K HUD Editor"));
        this.parent = parent;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        g.fill(0, 0, width, height, 0xD9080A10);
        g.drawCenteredString(font, "0456K HUD EDITOR", width / 2, 14, ClientMain.CONFIG.accent);
        g.drawCenteredString(font, "Drag widgets • F8 to reopen • R resets layout • ESC saves", width / 2, 30, 0xFF8B91A2);

        for (Box b : boxes()) {
            boolean hot = mouseX >= b.x && mouseX <= b.x + b.w && mouseY >= b.y && mouseY <= b.y + b.h;
            boolean active = b.id.equals(selected);
            int border = active ? ClientMain.CONFIG.accent : (hot ? 0xFF9098AA : 0xFF444957);
            g.fill(b.x - 1, b.y - 1, b.x + b.w + 1, b.y + b.h + 1, border);
            g.fill(b.x, b.y, b.x + b.w, b.y + b.h, 0xCC10121A);
            g.drawCenteredString(font, b.label, b.x + b.w / 2, b.y + (b.h - 8) / 2, 0xFFFFFFFF);
        }
        super.render(g, mouseX, mouseY, delta);
    }

    private List<Box> boxes() {
        List<Box> out = new ArrayList<>();
        add(out, HudLayout.CLIENT, "0456K", 132, 20);
        add(out, HudLayout.FPS, "FPS", 70, 18);
        add(out, HudLayout.COORDINATES, "XYZ", 125, 18);
        add(out, HudLayout.CPS, "CPS", 100, 18);
        add(out, HudLayout.KEYSTROKES, "KEYS", 88, 60);
        add(out, HudLayout.CROSSHAIR, "+", 20, 20);
        add(out, HudLayout.ARMOR, "ARMOR", 150, 38);
        return out;
    }

    private void add(List<Box> out, String id, String label, int w, int h) {
        HudLayout.Pos p = ClientMain.HUD.get(id);
        int x = p.x < 0 ? width / 2 - w / 2 : p.x;
        int y = p.y < 0 ? height / 2 - h / 2 : p.y;
        out.add(new Box(id, label, x, y, w, h));
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        for (Box b : boxes()) {
            if (mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h) {
                selected = b.id; grabX = (int)mx; grabY = (int)my;
                HudLayout.Pos p = ClientMain.HUD.get(b.id);
                originX = p.x < 0 ? b.x : p.x; originY = p.y < 0 ? b.y : p.y;
                return true;
            }
        }
        return true;
    }

    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (selected != null && button == 0) {
            ClientMain.HUD.set(selected, originX + (int)mx - grabX, originY + (int)my - grabY);
            clamp(selected);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    private void clamp(String id) {
        HudLayout.Pos p = ClientMain.HUD.get(id);
        if (p.x >= 0) p.x = Math.max(2, Math.min(width - 4, p.x));
        if (p.y >= 0) p.y = Math.max(42, Math.min(height - 4, p.y));
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 82) { ClientMain.HUD.defaults(); ClientMain.HUD.save(); return true; }
        if (keyCode == 256) { ClientMain.HUD.save(); onClose(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public void onClose() { ClientMain.HUD.save(); minecraft.setScreen(parent); }
    @Override public boolean shouldCloseOnEsc() { return false; }
}

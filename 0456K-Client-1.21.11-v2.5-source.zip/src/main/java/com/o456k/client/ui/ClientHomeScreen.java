package com.o456k.client.ui;

import com.o456k.client.ClientMain;
import com.o456k.client.core.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Polished client landing screen, accessible from the ClickGUI. */
public final class ClientHomeScreen extends Screen {
    private final Screen parent;
    public ClientHomeScreen(Screen parent) { super(Component.literal("0456K Client")); this.parent = parent; }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        long t = System.currentTimeMillis();
        int glow = (int)(Math.sin(t / 700.0) * 18 + 34);
        int bg = 0xFF000000 | (Math.max(10, Math.min(70, glow)) << 16) | (8 << 8) | 18;
        g.fill(0, 0, width, height, bg);
        for (int i = 0; i < 7; i++) {
            int x = (int)((t / (18.0 + i * 4) + i * 137) % (width + 120)) - 60;
            int y = (int)((Math.sin(t / (900.0 + i * 110) + i) * 90) + height * (0.25 + i * 0.08));
            g.fill(x, y, x + 90, y + 2, 0x203A8CFF);
        }
        int w = 620, h = 390, left = Math.max(20, (width - w) / 2), top = Math.max(20, (height - h) / 2);
        g.fill(left, top, left + w, top + h, 0xFF11151F);
        g.fill(left, top, left + 6, top + h, ClientMain.CONFIG.accent);
        g.drawString(font, "0456K CLIENT", left + 26, top + 24, ClientMain.CONFIG.accent);
        g.drawString(font, "PvP utility suite • Fabric 1.21.11", left + 26, top + 43, 0xFF8991A4);

        int enabled = 0;
        if (ClientMain.MODULES != null) for (Module m : ClientMain.MODULES.all()) if (m.enabled()) enabled++;
        card(g, left + 26, top + 76, 175, 82, "MODULES", enabled + " active", 0xFF8EA7FF);
        card(g, left + 218, top + 76, 175, 82, "HUD EDITOR", "F8 to open", 0xFF72D6B0);
        card(g, left + 410, top + 76, 175, 82, "CLICKGUI", "Right Shift", 0xFFF0C66E);

        button(g, left + 26, top + 184, 278, 44, "OPEN CLICKGUI", mouseX, mouseY);
        button(g, left + 316, top + 184, 278, 44, "HUD EDITOR", mouseX, mouseY);
        button(g, left + 26, top + 242, 278, 44, "FRIENDS  •  F6", mouseX, mouseY);
        button(g, left + 316, top + 242, 278, 44, "BACK TO MINECRAFT", mouseX, mouseY);
        button(g, left + 26, top + 300, 568, 36, "MODS  •  TEXTURE PACKS  •  VULKAN", mouseX, mouseY);
        g.drawString(font, "Built for lightweight PvP. Settings persist automatically.", left + 26, top + 350, 0xFF687083);
        g.drawString(font, "0456K", left + 26, top + 372, ClientMain.CONFIG.accent);
        super.render(g, mouseX, mouseY, delta);
    }

    private void card(GuiGraphics g, int x, int y, int w, int h, String title, String value, int accent) {
        g.fill(x, y, x+w, y+h, 0xFF181D28);
        g.fill(x, y, x+3, y+h, accent);
        g.drawString(font, title, x+14, y+14, 0xFF7F8799);
        g.drawString(font, value, x+14, y+39, 0xFFFFFFFF);
    }
    private void button(GuiGraphics g, int x, int y, int w, int h, String text, int mx, int my) {
        boolean hover = mx >= x && mx < x+w && my >= y && my < y+h;
        g.fill(x, y, x+w, y+h, hover ? 0xFF243244 : 0xFF1A202C);
        g.drawCenteredString(font, text, x+w/2, y+16, hover ? ClientMain.CONFIG.accent : 0xFFD6D9E1);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        int w=620,h=390,left=Math.max(20,(width-w)/2),top=Math.max(20,(height-h)/2);
        if (button == 0) {
            if (my>=top+184 && my<top+228 && mx<left+304) { minecraft.setScreen(new ClickGuiScreen(this)); return true; }
            if (my>=top+184 && my<top+228 && mx>=left+316) { minecraft.setScreen(new HudEditorScreen(this)); return true; }
            if (my>=top+242 && my<top+286 && mx < left+304) { minecraft.setScreen(new FriendsScreen(this)); return true; }
            if (my>=top+242 && my<top+286 && mx >= left+316) { onClose(); return true; }
            if (my>=top+300 && my<top+336) { minecraft.setScreen(new ClientLibraryScreen(this)); return true; }
        }
        return super.mouseClicked(mx,my,button);
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
}

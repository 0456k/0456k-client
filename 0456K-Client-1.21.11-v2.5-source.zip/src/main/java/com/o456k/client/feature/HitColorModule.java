package com.o456k.client.feature;
import com.o456k.client.core.*;
public final class HitColorModule extends Module { public HitColorModule(){super("HitColor","PvP damage flash foundation",Category.COMBAT);setEnabled(true);} }

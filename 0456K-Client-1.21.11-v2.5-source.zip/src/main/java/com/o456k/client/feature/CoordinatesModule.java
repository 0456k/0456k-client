package com.o456k.client.feature;
import com.o456k.client.core.*;
public final class CoordinatesModule extends Module {
    public CoordinatesModule(ClientConfig c){ super("Coordinates", "Player coordinates", Category.HUD); setEnabled(c.coordinates); }
}

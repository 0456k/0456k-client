package com.o456k.client.feature;

import com.o456k.client.core.Module;
import com.o456k.client.core.setting.BooleanSetting;
import net.minecraft.client.Minecraft;

/** Small, reversible client-side rendering optimizations. */
public final class PerformanceModule extends Module {
    public final BooleanSetting hideEntityShadows = addSetting(new BooleanSetting("Entity shadows", true));
    private Boolean previousShadows;

    public PerformanceModule() {
        super("Performance", "Lightweight PvP rendering optimizations", Category.RENDER);
    }

    @Override public void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        previousShadows = mc.options.entityShadows().get();
        apply(mc);
    }

    @Override public void tick(Minecraft client) { apply(client); }

    @Override public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (previousShadows != null) mc.options.entityShadows().set(previousShadows);
        previousShadows = null;
    }

    private void apply(Minecraft mc) {
        if (hideEntityShadows.get()) mc.options.entityShadows().set(false);
    }
}

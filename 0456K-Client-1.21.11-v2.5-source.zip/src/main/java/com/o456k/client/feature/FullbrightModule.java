package com.o456k.client.feature;
import com.o456k.client.core.*; import net.minecraft.client.Minecraft;
public final class FullbrightModule extends Module {
    private double previous = 1.0;
    public FullbrightModule(){ super("Fullbright", "Maximum client brightness", Category.RENDER); setEnabled(com.o456k.client.ClientMain.CONFIG.fullbright); }
    @Override public void onEnable(){ if(ClientMainRef.mc()!=null) { previous = ClientMainRef.mc().options.gamma().get(); ClientMainRef.mc().options.gamma().set(16.0); } }
    @Override public void tick(Minecraft m){ if(m.options!=null && m.options.gamma().get()<16.0) m.options.gamma().set(16.0); }
    @Override public void onDisable(){ Minecraft m=ClientMainRef.mc(); if(m!=null) m.options.gamma().set(previous); }
    private static final class ClientMainRef { static Minecraft mc(){ return Minecraft.getInstance(); } }
}

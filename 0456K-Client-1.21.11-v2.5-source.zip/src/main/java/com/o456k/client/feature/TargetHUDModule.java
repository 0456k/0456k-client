package com.o456k.client.feature;

import com.o456k.client.core.Module;
import com.o456k.client.core.setting.BooleanSetting;
import com.o456k.client.core.setting.NumberSetting;

public final class TargetHUDModule extends Module {
    public final NumberSetting scale = addSetting(new NumberSetting("Scale", 1.0, 0.75, 1.5, 0.05));
    public final BooleanSetting showDistance = addSetting(new BooleanSetting("Distance", true));
    public final BooleanSetting showHealth = addSetting(new BooleanSetting("Health", true));

    public TargetHUDModule() {
        super("TargetHUD", "Shows basic information for the entity under your crosshair", Category.HUD);
    }
}

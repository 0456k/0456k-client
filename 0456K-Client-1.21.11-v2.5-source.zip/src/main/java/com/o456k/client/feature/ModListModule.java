package com.o456k.client.feature;

import com.o456k.client.core.Module;
import net.fabricmc.loader.api.FabricLoader;
import java.util.List;

public final class ModListModule extends Module {
    public ModListModule() { super("ModList", "Provides the installed-mod catalog for the client Mods tab.", Category.MISC); }
    public List<String> installedMods() {
        return FabricLoader.getInstance().getAllMods().stream()
                .map(m -> m.getMetadata().getId())
                .sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }
}

package com.o456k.client.feature;

import com.o456k.client.core.Module;
import net.minecraft.client.Minecraft;

public final class ServerInfoModule extends Module {
    public ServerInfoModule() { super("ServerInfo", "Shows the current server address and ping.", Category.HUD); }
    public String address(Minecraft client) {
        if (client.getCurrentServer() != null) return client.getCurrentServer().ip;
        if (client.hasSingleplayerServer()) return "Singleplayer";
        return "Not connected";
    }
    public int ping(Minecraft client) {
        if (client.player == null || client.getConnection() == null) return -1;
        var info = client.getConnection().getPlayerInfo(client.player.getUUID());
        return info == null ? -1 : info.getLatency();
    }
}

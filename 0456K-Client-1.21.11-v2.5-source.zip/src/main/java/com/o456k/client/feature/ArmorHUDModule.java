package com.o456k.client.feature;
import com.o456k.client.core.*;
public final class ArmorHUDModule extends Module {
    public ArmorHUDModule(ClientConfig c){ super("Armor", "Armor durability HUD", Category.HUD); setEnabled(c.armor); }
}

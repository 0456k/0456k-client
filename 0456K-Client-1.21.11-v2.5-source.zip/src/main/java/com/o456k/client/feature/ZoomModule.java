package com.o456k.client.feature;

import com.o456k.client.ClientMain;
import com.o456k.client.core.*;
import net.minecraft.client.Minecraft;

/** Hold-to-zoom module. The FOV is restored exactly when zoom ends. */
public final class ZoomModule extends Module {
    private double previousFov = -1;
    private final com.o456k.client.core.setting.NumberSetting zoomFov = addSetting(new com.o456k.client.core.setting.NumberSetting("Zoom FOV", 25.0, 10.0, 70.0, 1.0));
    private final com.o456k.client.core.setting.NumberSetting smoothness = addSetting(new com.o456k.client.core.setting.NumberSetting("Smoothness", 0.35, 0.05, 1.0, 0.05));
    private boolean zooming;

    public ZoomModule(ClientConfig c){
        super("Zoom", "Smooth hold-to-zoom", Category.RENDER);
        setEnabled(c.zoom);
    }

    @Override public void tick(Minecraft m){
        if (m.options == null) return;
        boolean wantsZoom = enabled() && ClientMain.isZoomHeld();
        if (wantsZoom && !zooming) {
            previousFov = m.options.fov().get();
            zooming = true;
        }
        if (wantsZoom) {
            double target = zoomFov.get();
            double current = m.options.fov().get();
            m.options.fov().set(current + (target - current) * smoothness.get());
        } else if (zooming) {
            double target = previousFov < 0 ? 70.0 : previousFov;
            double current = m.options.fov().get();
            double next = current + (target - current) * smoothness.get();
            if (Math.abs(next - target) < 0.15) {
                next = target; zooming = false; previousFov = -1;
            }
            m.options.fov().set(next);
        }
    }

    @Override public void onDisable(){
        Minecraft m = Minecraft.getInstance();
        if (zooming && previousFov >= 0 && m.options != null) m.options.fov().set(previousFov);
        zooming = false; previousFov = -1;
    }
}

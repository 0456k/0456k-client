package com.o456k.client.feature;
import com.o456k.client.core.*;
public final class CrosshairModule extends Module {
    public final com.o456k.client.core.setting.NumberSetting size = addSetting(new com.o456k.client.core.setting.NumberSetting("Size", 5.0, 2.0, 12.0, 1.0));
    public final com.o456k.client.core.setting.NumberSetting thickness = addSetting(new com.o456k.client.core.setting.NumberSetting("Thickness", 2.0, 1.0, 5.0, 1.0));
    public CrosshairModule(){super("Crosshair","PvP crosshair overlay",Category.HUD);setEnabled(true);}
}

package com.o456k.client.feature;

import com.o456k.client.core.Module;
import net.minecraft.client.Minecraft;
import java.util.List;

public final class ResourcePackListModule extends Module {
    public ResourcePackListModule() { super("TexturePacks", "Provides the installed resource-pack catalog.", Category.MISC); }
    public List<String> selectedPacks(Minecraft client) {
        return client.getResourcePackRepository().getSelectedPacks().stream()
                .map(p -> p.getId().toString())
                .sorted(String.CASE_INSENSITIVE_ORDER).toList();
    }
}

package com.o456k.client.feature;
import com.o456k.client.core.*; import net.minecraft.client.Minecraft;
public final class ToggleSneakModule extends Module { private boolean sneaking;
    public ToggleSneakModule(){super("ToggleSneak","Toggle crouch instead of holding",Category.MOVEMENT);}
    @Override public void tick(Minecraft m){ if(m.player!=null && sneaking) m.options.keyShift.setDown(true); }
}

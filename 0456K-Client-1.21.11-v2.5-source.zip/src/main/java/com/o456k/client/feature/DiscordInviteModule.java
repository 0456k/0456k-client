package com.o456k.client.feature;

import com.o456k.client.core.Module;

public final class DiscordInviteModule extends Module {
    public DiscordInviteModule() { super("Discord", "Displays the 0456K Discord invite in the HUD.", Category.HUD); }
    public static final String INVITE = "discord.gg/zWZxvmUczW";
}

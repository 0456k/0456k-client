package com.o456k.client.feature;

import com.o456k.client.core.Module;

public final class FriendsHUDModule extends Module {
    public FriendsHUDModule() { super("FriendsHUD", "Shows the number of saved friends.", Category.HUD); }
}

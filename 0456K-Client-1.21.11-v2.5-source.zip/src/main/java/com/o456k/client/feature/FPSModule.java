package com.o456k.client.feature;
import com.o456k.client.core.*;
public final class FPSModule extends Module {
    public FPSModule(ClientConfig c){ super("FPS", "Frames per second", Category.HUD); setEnabled(c.fps); }
}

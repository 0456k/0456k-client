package com.o456k.client.feature;
import com.o456k.client.core.*;
public final class KeystrokesModule extends Module {
    public KeystrokesModule(ClientConfig c){ super("Keystrokes", "WASD + mouse buttons", Category.HUD); setEnabled(c.keystrokes); }
}

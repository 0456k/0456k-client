package com.o456k.client.feature;

import com.o456k.client.ClientMain;
import com.o456k.client.core.*;
import net.minecraft.client.Minecraft;
import java.util.ArrayDeque;
import java.util.Deque;

/** Rolling one-second click counter. */
public final class CPSModule extends Module {
    private final Deque<Long> left = new ArrayDeque<>();
    private final Deque<Long> right = new ArrayDeque<>();
    private boolean lastLeft, lastRight;
    private int leftCps, rightCps;

    public CPSModule(ClientConfig c){ super("CPS", "Rolling left/right clicks per second", Category.HUD); setEnabled(c.cps); }

    @Override public void tick(Minecraft m){
        long now = System.currentTimeMillis();
        boolean l = m.mouseHandler.isLeftPressed();
        boolean r = m.mouseHandler.isRightPressed();
        if (l && !lastLeft) left.addLast(now);
        if (r && !lastRight) right.addLast(now);
        lastLeft=l; lastRight=r;
        prune(left, now); prune(right, now);
        leftCps=left.size(); rightCps=right.size();
    }

    private static void prune(Deque<Long> q,long now){ while(!q.isEmpty() && now-q.peekFirst()>1000) q.removeFirst(); }
    public int leftCps(){ return leftCps; }
    public int rightCps(){ return rightCps; }
}

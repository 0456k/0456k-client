package com.o456k.client.feature;
import com.o456k.client.core.*; import net.minecraft.client.Minecraft;
public final class SprintModule extends Module {
    private final com.o456k.client.core.setting.BooleanSetting omni = addSetting(new com.o456k.client.core.setting.BooleanSetting("Omni Sprint", false));
    public SprintModule(ClientConfig c){ super("Sprint", "Automatically sprint while moving", Category.MOVEMENT); setEnabled(c.sprint); }
    @Override public void tick(Minecraft m){ if(m.player!=null && !m.player.isSpectator() && (omni.get() ? (m.player.input.getMoveVector().lengthSqr() > 0.0001f) : m.player.input.hasForwardImpulse()) && !m.player.isCrouching()) m.player.setSprinting(true); }
}

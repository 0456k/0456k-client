# 0456K Client release checklist

## Target
- Minecraft Java 1.21.11
- Fabric Loader 0.18.1
- Fabric API 0.141.6+1.21.11
- Java 21
- Fabric Loom 1.14.6

## Local build
Run `gradlew.bat build` on Windows or `./gradlew build` on macOS/Linux after the standard Gradle wrapper JAR is present.

The source archive intentionally does not claim a compiled JAR until the Gradle dependency graph has been resolved and the project has completed a real `build` task.

## Release checks
1. `build` completes without Java compilation errors.
2. `build/libs/0456k-client-2.0.0.jar` exists.
3. Launch Fabric 1.21.11 with Java 21.
4. Verify Right Shift, F7, F8, and C bindings.
5. Verify module/config/HUD persistence after restart.

## v2.2.0 — Feature Systems Expansion

- Added persistent named profiles with module state, keybinds, and settings snapshots.
- Added a persistent local Friends manager.
- Added ServerInfo HUD module with current server address and latency.
- Added Discord invite HUD module.
- Wired profiles/friends into client startup.
- Updated client version to 2.2.0.

Build verification is still pending because this source bundle does not include the Gradle wrapper JAR and no system Gradle executable is available in the current environment.

# 0456K Client

Minecraft Java 1.21.11 / Fabric / Java 21 PvP client foundation.

## Included
- Right Shift Click GUI
- Module system
- Sprint
- Fullbright
- Zoom module foundation
- FPS HUD
- Coordinates HUD
- Keystrokes HUD
- CPS/Armor module foundations
- Persistent JSON configuration
- Client-only architecture
- Official Mojang mappings

## Build
Use Java 21 and run `gradlew.bat build` on Windows or `./gradlew build` on macOS/Linux. The remapped jar is written to `build/libs/`.

Target versions: Minecraft 1.21.11, Fabric Loader 0.18.1, Loom 1.14.6, Fabric API 0.141.6+1.21.11.

## v1.3 additions
- Persistent module keybinds
- Default Sprint/Zoom/Fullbright/ToggleSneak bindings
- Right-click any module in ClickGUI to rebind it
- Keyboard edge detection so held keys do not repeatedly toggle modules


## v1.4
- Draggable HUD editor (F8)
- Persistent HUD positions
- Reset HUD layout with R
- Configurable positions for FPS, XYZ, CPS, keystrokes, crosshair, armor, and client branding

## v1.7 Settings Pass
- Generic module setting framework
- Per-module settings screen
- Zoom FOV and smoothing controls
- Sprint Omni Sprint option
- Crosshair size and thickness controls
- Settings open from the `SET` control in ClickGUI

## v1.9 additions
- Persistent module enabled state for every module.
- Persistent module setting values, including Zoom, Sprint, Crosshair, TargetHUD, and Performance settings.
- Settings are restored during client startup and saved immediately when changed.

## v1.8 additions
- Performance module with reversible entity-shadow optimization.
- TargetHUD module with scale, distance, and health-bar settings.
- TargetHUD reads the entity already under the vanilla crosshair; it does not automate targeting or attack.


## v2.0 release hardening
- Search now filters by module name and description consistently.
- Keybind collisions are resolved automatically when rebinding.
- Config and HUD writes use temporary files with atomic replacement when supported.
- Version bumped to 2.0.0.

### Build note
The source includes Gradle configuration and the wrapper properties, but this archive does not contain the Gradle wrapper JAR. Generate the wrapper once on a machine with Gradle installed (`gradle wrapper`) or use a local Gradle 8.14.3+ installation, then run `gradlew build`.
